#!/usr/bin/env python3
"""Sintetiza os sons da Harpa de Sculk (pluck de harpa + eco etéreo + zumbido grave) e converte para OGG mono.
Uso: python3 build_harp_sounds.py   (requer numpy e ffmpeg com libvorbis)"""
import os, subprocess, wave, json, tempfile
import numpy as np
SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src/main/resources/assets/sculkharp")
rs = np.random.RandomState(5)

def pluck(freq, dur=1.8, bright=0.5):
    n = int(SR * dur); N = int(SR / freq); buf = rs.uniform(-1, 1, N) * 0.8; out = np.zeros(n)
    for i in range(n):
        j = i % N; out[i] = buf[j]; buf[j] = bright * buf[j] + (1 - bright) * buf[(j + 1) % N] * 0.998 if False else 0.5 * (buf[j] + buf[(j + 1) % N]) * 0.9985
    t = np.arange(n) / SR
    out += 0.25 * np.sin(2 * np.pi * freq * 2 * t) * np.exp(-t * 3) + 0.12 * np.sin(2 * np.pi * freq * 3.01 * t) * np.exp(-t * 5)
    return out * np.minimum(1, t * 400)

def echo(x, taps=((0.19, 0.42), (0.37, 0.27), (0.58, 0.16), (0.8, 0.09))):
    y = np.zeros(len(x) + int(SR * 1.0)); y[:len(x)] += x
    for d, g in taps:
        k = int(SR * d); seg = x.copy()
        seg = np.convolve(seg, np.ones(24) / 24, mode="same")      # eco "abafado"/etéreo
        y[k:k + len(x)] += seg * g
    return y

def hum(dur, f0=55.0, f1=None, level=0.5):
    t = np.arange(int(SR * dur)) / SR; f = f0 if f1 is None else np.linspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    wob = 1 + 0.25 * np.sin(2 * np.pi * 7 * t)
    return level * (np.sin(ph) + 0.35 * np.sin(2 * ph + 1)) * wob

def fade(x, a=0.01, r=0.25):
    n = len(x); e = np.ones(n); na, nr = int(SR * a), int(SR * r)
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.linspace(1, 0, nr); return x * e

def norm(x, peak=0.85): return x / (np.max(np.abs(x)) + 1e-9) * peak

def write(name, x):
    x = np.clip(norm(x), -1, 1)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf: p = tf.name
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype("<i2").tobytes())
    d = os.path.join(OUT, "sounds"); os.makedirs(d, exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "4", "-ac", "1", "-ar", "44100",
                    os.path.join(d, name + ".ogg")], check=True); os.remove(p)

# 3 variações de pluck (C5, E5, G5): agudo + eco etéreo + fio de zumbido grave
for i, f in enumerate((523.25, 659.25, 783.99), 1):
    x = echo(pluck(f)); n = len(x)
    x[:int(SR * 1.2)] += hum(1.2, 55, level=0.07) * np.exp(-np.arange(int(SR * 1.2)) / SR * 2.5)
    write(f"harp_pluck_{i}", fade(x[:int(SR * 2.4)], r=0.5))
# carga: zumbido grave crescente + arpejo ascendente de cristal
n = int(SR * 1.6); x = hum(1.6, 48, 70, 0.55) * np.linspace(0.2, 1, n)
for k, f in enumerate((392, 523.25, 659.25, 783.99, 1046.5, 1318.5)):
    s = int(SR * 0.22 * k); p = pluck(f, 0.9) * (0.3 + 0.1 * k)
    x[s:s + len(p)] += p[:max(0, n - s)] if s + len(p) > n else p
write("harp_charge", fade(x, 0.02, 0.2))
# onda de ressonância: acorde + "womp" grave descendente + sopro + eco longo
dur = 2.2; n = int(SR * dur); x = np.zeros(n)
for f in (261.63, 392.0, 523.25, 783.99): x += pluck(f, dur)[:n] * 0.5
x += hum(dur, 90, 38, 0.9) * np.exp(-np.arange(n) / SR * 1.4)
noise = rs.uniform(-1, 1, n); noise = np.convolve(noise, np.ones(40) / 40, "same") * np.exp(-np.arange(n) / SR * 6) * 0.5
x += noise
write("harp_wave", fade(echo(x)[:int(SR * 3.0)], 0.005, 0.8))
sounds = {
 "harp_pluck": {"subtitle": "subtitles.sculkharp.harp_pluck", "sounds": [f"sculkharp:harp_pluck_{i}" for i in (1, 2, 3)]},
 "harp_charge": {"subtitle": "subtitles.sculkharp.harp_charge", "sounds": ["sculkharp:harp_charge"]},
 "harp_wave": {"subtitle": "subtitles.sculkharp.harp_wave", "sounds": ["sculkharp:harp_wave"]}}
json.dump(sounds, open(os.path.join(OUT, "sounds.json"), "w"), indent=2)
print("sons ok")

package com.sculkharp;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Registros de cliente da harpa (barramento MOD): provedores de partículas e propriedades de modelo. */
@Mod.EventBusSubscriber(modid = SculkHarpMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class HarpClientEvents {
    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent e) {
        e.registerSpriteSet(ModParticles.SCULK_NOTE.get(), s -> new HarpParticle.Provider(s, HarpParticle.Kind.NOTE));
        e.registerSpriteSet(ModParticles.SCULK_SHARD.get(), s -> new HarpParticle.Provider(s, HarpParticle.Kind.SHARD));
        e.registerSpriteSet(ModParticles.SCULK_SPARK.get(), s -> new HarpParticle.Provider(s, HarpParticle.Kind.SPARK));
        e.registerSpriteSet(ModParticles.SCULK_RING.get(), s -> new HarpParticle.Provider(s, HarpParticle.Kind.RING));
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            SculkHarpItem harp = ModItems.SCULK_HARP.get();
            // "playing": 1 enquanto toca (cordas acesas); "power": 0..1 da carga (cristais mais brilhantes)
            ItemProperties.register(harp, new ResourceLocation("playing"), (stack, level, entity, seed) ->
                    entity != null && entity.isUsingItem() && entity.getUseItem().getItem() == stack.getItem() ? 1.0F : 0.0F);
            ItemProperties.register(harp, new ResourceLocation("power"), (stack, level, entity, seed) ->
                    entity != null && entity.isUsingItem() && entity.getUseItem().getItem() == stack.getItem()
                            ? SculkHarpItem.chargeFraction(entity.getTicksUsingItem()) : 0.0F);
        });
    }
}

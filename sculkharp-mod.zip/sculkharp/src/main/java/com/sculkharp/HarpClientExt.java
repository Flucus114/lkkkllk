package com.sculkharp;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Extensões de cliente da harpa: pose de duas mãos (a mesma da besta carregada) em terceira pessoa. */
public final class HarpClientExt implements IClientItemExtensions {
    public static final HarpClientExt INSTANCE = new HarpClientExt();

    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return hand == InteractionHand.MAIN_HAND ? HumanoidModel.ArmPose.CROSSBOW_HOLD : null;
    }
}

package com.sculkharp;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

/**
 * Harpa de Sculk: arma-instrumento.
 *  - Segure o botão direito: toca notas (pentatônica) enquanto as cristais acumulam energia.
 *  - Solte depois de {@link HarpConfig#MIN_TICKS}: Onda de Ressonância (dano + empurrão em área), com raio/dano
 *    proporcionais à carga. Soltar antes disso só toca (sem recarga).
 * Sem receita nem loot: aba criativa do mod ou /give sculkharp:sculk_harp.
 */
public class SculkHarpItem extends Item {
    /** Notas da escala pentatônica (razões de afinação aplicadas ao pitch do som base). */
    private static final float[] SCALE = {1.0F, 1.1225F, 1.2599F, 1.4983F, 1.6818F, 2.0F};

    public SculkHarpItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.NONE; }
    @Override public int getUseDuration(ItemStack stack) { return 72000; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        player.startUsingItem(hand);
        if (!level.isClientSide) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.HARP_CHARGE.get(), SoundSource.PLAYERS, 0.8F, 1.0F);
        }
        return InteractionResultHolder.consume(stack);
    }

    /** Ponto (mundo) aproximado da harpa/cristais, à frente do peito do usuário. */
    private static Vec3 anchor(LivingEntity e) {
        return e.getEyePosition().add(e.getLookAngle().scale(0.65D)).add(0.0D, -0.3D, 0.0D);
    }

    public static float chargeFraction(int ticksUsing) {
        return Mth.clamp(ticksUsing / (float) HarpConfig.CHARGE_TICKS.get(), 0.0F, 1.0F);
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
        int ticks = getUseDuration(stack) - remaining;
        float charge = chargeFraction(ticks);
        Vec3 a = anchor(user);
        if (level.isClientSide) {
            // energia acumulando: fragmentos e faíscas convergem para os cristais (cada vez mais com a carga)
            int n = 1 + (int) (charge * 3);
            for (int i = 0; i < n; i++) {
                double ang = level.random.nextDouble() * Math.PI * 2, dist = 0.7D + level.random.nextDouble() * 0.5D;
                double ox = Math.cos(ang) * dist, oz = Math.sin(ang) * dist, oy = (level.random.nextDouble() - 0.3D) * 0.9D;
                level.addParticle(level.random.nextBoolean() ? ModParticles.SCULK_SHARD.get() : ModParticles.SCULK_SPARK.get(),
                        a.x + ox, a.y + oy, a.z + oz, -ox * 0.11D, -oy * 0.11D + 0.02D, -oz * 0.11D);
            }
            return;
        }
        int interval = HarpConfig.PLUCK_INTERVAL.get();
        if (ticks > 0 && ticks % interval == 0) {
            int idx = level.random.nextInt(SCALE.length);
            level.playSound(null, user.getX(), user.getY(), user.getZ(), ModSounds.HARP_PLUCK.get(), SoundSource.PLAYERS,
                    0.7F, SCALE[idx] * (0.9F + charge * 0.2F));
            ServerLevel sl = (ServerLevel) level;
            sl.sendParticles(ModParticles.SCULK_NOTE.get(), a.x, a.y + 0.25D, a.z, 1 + (int) (charge * 2), 0.3, 0.2, 0.3, 0.0);
        }
        if (ticks == HarpConfig.CHARGE_TICKS.get()) {   // carga completa: pulso de aviso
            level.playSound(null, user.getX(), user.getY(), user.getZ(), ModSounds.HARP_PLUCK.get(), SoundSource.PLAYERS, 1.0F, 2.0F);
            ((ServerLevel) level).sendParticles(ModParticles.SCULK_RING.get(), user.getX(), user.getY() + 0.1D, user.getZ(), 0, 1.6D, 0.0D, 0.0D, 1.0D);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int timeLeft) {
        if (level.isClientSide || !(user instanceof Player player)) return;
        int ticks = getUseDuration(stack) - timeLeft;
        if (ticks < HarpConfig.MIN_TICKS.get()) return;     // só tocou
        float charge = chargeFraction(ticks);
        double radius = HarpConfig.RADIUS.get() * (0.5D + 0.5D * charge);
        float damage = (float) Mth.lerp(charge, HarpConfig.MIN_DAMAGE.get(), HarpConfig.MAX_DAMAGE.get());
        ServerLevel sl = (ServerLevel) level;

        int hit = 0;
        Vec3 c = player.position();
        for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                t -> t != player && t.isAlive() && !(t instanceof ArmorStand) && !t.isAlliedTo(player)
                        && !(t instanceof TamableAnimal ta && ta.isOwnedBy(player)) && t.distanceToSqr(player) <= radius * radius)) {
            if (t.hurt(level.damageSources().sonicBoom(player), damage)) {
                hit++;
                Vec3 dir = t.position().subtract(c).multiply(1.0D, 0.0D, 1.0D);
                if (dir.lengthSqr() > 1.0E-4D && HarpConfig.KNOCKBACK.get() > 0.0D) {
                    dir = dir.normalize().scale(HarpConfig.KNOCKBACK.get() * (0.5D + 0.5D * charge));
                    t.push(dir.x, 0.25D, dir.z);
                    t.hurtMarked = true;
                }
                sl.sendParticles(ModParticles.SCULK_SHARD.get(), t.getX(), t.getY(0.5D), t.getZ(), 6, 0.3, 0.4, 0.3, 0.05);
            }
        }

        // ondas de energia se expandindo + dispersão dos fragmentos acumulados
        double y = player.getY() + 0.12D;
        sl.sendParticles(ModParticles.SCULK_RING.get(), player.getX(), y, player.getZ(), 0, radius, 0.0D, 0.0D, 1.0D);
        sl.sendParticles(ModParticles.SCULK_RING.get(), player.getX(), y + 0.5D, player.getZ(), 0, radius * 0.65D, 0.0D, 0.0D, 1.0D);
        Vec3 a = anchor(player);
        int bursts = 14 + (int) (charge * 18);
        for (int i = 0; i < bursts; i++) {
            double ang = i * Math.PI * 2 / bursts, sp = 0.25D + level.random.nextDouble() * 0.25D;
            sl.sendParticles(i % 3 == 0 ? ModParticles.SCULK_NOTE.get() : ModParticles.SCULK_SHARD.get(), a.x, a.y, a.z, 0,
                    Math.cos(ang), (level.random.nextDouble() - 0.3D) * 0.6D, Math.sin(ang), sp);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.HARP_WAVE.get(), SoundSource.PLAYERS, 1.2F, 0.95F + charge * 0.1F);
        player.getCooldowns().addCooldown(this, HarpConfig.COOLDOWN_TICKS.get());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.sculkharp.sculk_harp.lore1").withStyle(ChatFormatting.DARK_AQUA, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("item.sculkharp.sculk_harp.lore2").withStyle(ChatFormatting.DARK_AQUA, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("item.sculkharp.sculk_harp.ability").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("item.sculkharp.sculk_harp.play").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(HarpClientExt.INSTANCE);
    }
}
